package JavaTest.Ex03;

public class Student {
    int no;
    String name;
    int score;
    String className;

    public Student(int no, String name, int score, String className) {
        this.no = no;
        this.name = name;
        this.score = score;
        this.className = className;
    }
}